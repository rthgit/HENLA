import argparse, json, hashlib, math, random
from pathlib import Path
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def get_path(obj, path):
    cur = obj
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur

def hash_bucket(text, dim):
    return int(hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest(), 16) % dim

def featurize(obj, dim=768, exclude_target=None):
    vec = torch.zeros(dim, dtype=torch.float32)

    def add_num(name, value):
        if exclude_target and name == exclude_target:
            return
        try:
            v = float(value)
        except Exception:
            return
        if math.isfinite(v):
            vec[hash_bucket("num:"+name, dim)] += max(min(v, 10.0), -10.0) / 10.0

    def add_text(name, value):
        if exclude_target and name == exclude_target:
            return
        text = str(value)
        toks = text.replace("/", " ").replace("_", " ").replace("-", " ").split() or [text[:64]]
        for tok in toks[:32]:
            vec[hash_bucket("txt:"+name+":"+tok.lower(), dim)] += 1.0

    def walk(x, prefix=""):
        if isinstance(x, dict):
            for k, v in x.items():
                walk(v, f"{prefix}.{k}" if prefix else k)
        elif isinstance(x, list):
            for i, v in enumerate(x[:30]):
                walk(v, f"{prefix}[{i}]")
        elif isinstance(x, bool):
            add_num(prefix, 1.0 if x else 0.0)
        elif isinstance(x, (int, float)):
            add_num(prefix, x)
        elif x is None:
            add_text(prefix, "none")
        else:
            add_text(prefix, x)

    walk(obj)
    n = vec.norm()
    return vec / n if n > 0 else vec

def build(rows, target, dim):
    xs, ys = [], []
    for r in rows:
        y = get_path(r, target)
        if isinstance(y, bool):
            y = 1.0 if y else 0.0
        if not isinstance(y, (int, float)) or not math.isfinite(float(y)):
            continue
        xs.append(featurize(r, dim, exclude_target=target))
        ys.append([float(y)])
    if not xs:
        raise RuntimeError(f"No usable rows for target {target}")
    return torch.stack(xs), torch.tensor(ys, dtype=torch.float32)

class MLP(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, 256), nn.ReLU(), nn.LayerNorm(256), nn.Dropout(0.1),
            nn.Linear(256, 128), nn.ReLU(), nn.LayerNorm(128),
            nn.Linear(128, 1)
        )
    def forward(self, x):
        return self.net(x)

@torch.no_grad()
def eval_model(model, x, y, device):
    model.eval()
    pred = model(x.to(device)).cpu()
    mse = torch.mean((pred-y)**2).item()
    mae = torch.mean(torch.abs(pred-y)).item()
    if len(y) > 1 and torch.std(pred) > 0 and torch.std(y) > 0:
        corr = torch.corrcoef(torch.stack([pred.squeeze(), y.squeeze()]))[0,1].item()
    else:
        corr = 0.0
    return {"mse": mse, "mae": mae, "corr": corr}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", required=True)
    ap.add_argument("--val", required=True)
    ap.add_argument("--test", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--name", default="target_predictor")
    ap.add_argument("--dim", type=int, default=768)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    random.seed(7); torch.manual_seed(7)

    train_rows, val_rows, test_rows = map(load_jsonl, [args.train, args.val, args.test])
    xtr, ytr = build(train_rows, args.target, args.dim)
    xv, yv = build(val_rows, args.target, args.dim)
    xt, yt = build(test_rows, args.target, args.dim)

    device = "cuda" if args.device == "cuda" and torch.cuda.is_available() else "cpu"
    model = MLP(args.dim).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    loss_fn = nn.MSELoss()
    loader = DataLoader(TensorDataset(xtr, ytr), batch_size=args.batch_size, shuffle=True)

    mean = ytr.mean()
    baseline = {
        "val_mse": torch.mean((yv-mean)**2).item(),
        "test_mse": torch.mean((yt-mean)**2).item(),
        "train_target_mean": mean.item(),
        "train_target_std": ytr.std().item() if len(ytr) > 1 else 0.0,
    }

    best = float("inf"); best_state = None; hist = []
    for e in range(1, args.epochs+1):
        model.train(); losses=[]
        for xb,yb in loader:
            xb,yb=xb.to(device),yb.to(device)
            loss=loss_fn(model(xb),yb)
            opt.zero_grad(); loss.backward(); opt.step()
            losses.append(loss.item())
        m=eval_model(model,xv,yv,device)
        hist.append({"epoch":e,"train_mse":sum(losses)/len(losses),**m})
        if m["mse"] < best:
            best=m["mse"]; best_state={k:v.detach().cpu() for k,v in model.state_dict().items()}
        if e==1 or e%10==0:
            print(f"epoch={e:03d} train={hist[-1]['train_mse']:.6f} val={m['mse']:.6f} mae={m['mae']:.6f} corr={m['corr']:.4f}")

    if best_state: model.load_state_dict(best_state)
    val=eval_model(model,xv,yv,device); test=eval_model(model,xt,yt,device)

    out=Path("artifacts/neural")
    (out/"models").mkdir(parents=True,exist_ok=True)
    (out/"reports").mkdir(parents=True,exist_ok=True)
    safe=args.name.replace("/","_").replace(".","_")
    model_path=out/"models"/f"{safe}.pt"
    report_path=out/"reports"/f"{safe}_report.json"

    report={
        "name":args.name,"target":args.target,"device":device,
        "records":{"train":len(xtr),"val":len(xv),"test":len(xt)},
        "baseline":baseline,
        "model":{"val":val,"test":test},
        "beats_baseline_val": val["mse"] < baseline["val_mse"],
        "beats_baseline_test": test["mse"] < baseline["test_mse"],
        "history":hist,
    }
    torch.save({"state_dict":model.state_dict(),"report":report,"dim":args.dim}, model_path)
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")

    print("\n=== FINAL REPORT ===")
    print(json.dumps({k:report[k] for k in ["name","target","device","records","baseline","model","beats_baseline_val","beats_baseline_test"]},indent=2))
    print("saved:", model_path, report_path)

if __name__ == "__main__":
    main()
